#!/usr/bin/python3
"""
parse the tomcat instances defined in the config.yml configuration file
"""

import sys
import json
import yaml

def constructor(loader, node):
    """
    returns a mapping constructed using the specified YAML tags from the passed loader and node
    """
    return loader.construct_mapping(node)

yaml.add_constructor('!Config', constructor)
yaml.add_constructor('!Defaults', constructor)
yaml.add_constructor('!TomcatInstance', constructor)

try:
    with open('conf.yml', 'r', encoding="utf-8") as file:
        config = yaml.load(file, Loader=yaml.Loader)
except BaseException as e:  # Last resort for truly unexpected errors
    print(e)
    sys.exit(1)
print('\n############## Config in YAML format\n')
yaml.dump(config, sys.stdout, default_flow_style=False)
print('\n############## Config in JSON format\n')
print(json.dumps(config, indent=4))
