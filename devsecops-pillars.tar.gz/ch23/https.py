#!/usr/bin/python3

import http.server
import ssl
import socketserver
import argparse
import sys

key_file = "cert.key"
cert_file = "cert.crt"
truststore_file = None

parser = argparse.ArgumentParser(description='fancymonitor application')
parser.add_argument("-k", "--key-file", dest="key_file",
                    help="path to the certificate's private key file - defaults to '{}'".format(key_file),
                    default=key_file)
parser.add_argument("-c", "--cert-file", dest="cert_file",
                    help="path to the certificate's file - defaults to '{}'".format(cert_file), default=cert_file)
parser.add_argument("-t", "--truststore-file", dest="truststore_file",
                    help="path to the PEM encoded truststore file - optional for mutual TLS")

args = parser.parse_args()

if args.key_file:
    key_file = args.key_file
if args.cert_file:
    cert_file = args.cert_file
if args.truststore_file:
    truststore_file = args.truststore_file

try:
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=cert_file, keyfile=key_file)

    if truststore_file:
        context.load_verify_locations(cafile=truststore_file)
        context.verify_mode = ssl.CERT_REQUIRED
        print("Mutual TLS is enabled - Truststore file is {}".format(truststore_file))

    server_address = ("0.0.0.0", 8443)

    handler = http.server.SimpleHTTPRequestHandler
    with socketserver.TCPServer(server_address, handler) as httpd:
        httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
        print("Serving on https://{}:{}".format(server_address[0],server_address[1]))
        httpd.serve_forever()
except Exception as e:
    print(e, file=sys.stderr)
    exit(1)
