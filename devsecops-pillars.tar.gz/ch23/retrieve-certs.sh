#!/bin/bash
echo | openssl s_client -connect ${1}:443 -servername ${1} -showcerts | sed -n '/-----BEGIN CERTIFICATE-----/,/-----END CERTIFICATE-----/p' | awk 'BEGIN {c=0} /-----BEGIN CERTIFICATE-----/{c++} {print > "cert" c ".pem"}'

cnt=0
for certfile in $(ls cert*.pem); do
    cn=$(openssl x509 -in ${certfile} --noout -subject | sed 's/.*CN[ ]*=[ ]*\(.*\)*/\1/' | tr ' ' '-')
    mv -f ${certfile} ${cn}.crt
    subj=$(openssl x509 -in ${cn}.crt --noout -subject)
    echo File ${cn}.crt: ${subj}
    if [[ ${cnt} -gt 0 ]]; then
        cat ${cn}.crt >> ca-chain.pem
    else
        truncate -s0 ca-chain.pem
    fi
    ((cnt++))
done
echo "Intermediate CA's certificates saved as ca-chain.pem"
