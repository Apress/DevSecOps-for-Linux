#!/usr/bin/python3
"""
Example Python script to show how to call REST endpoints
"""

import json
import urllib3


def call_endpoint(method, url):
    """
    Print node information to standard output
    """
    http = urllib3.PoolManager()

    try:
        response = http.request(method, url)
        if response.status == 200:
            data = response.data.decode('utf-8')
            json_data = json.loads(data)
            print(json.dumps(json_data, indent=4))
        else:
            print(f"Error: Received response with status {response.status}")
    except Exception as exception:
        print(f"An error occurred: {exception}")

if __name__ == "__main__":
    call_endpoint('GET',"http://localhost:3000/api/v1/version")
