#!/usr/bin/python3
"""
Example Python script to show how to call SOAP endpoints
"""

import requests
from tenacity import retry, stop_after_attempt, wait_fixed



@retry(stop=stop_after_attempt(5), wait=wait_fixed(2))
def make_post_request(url):
    """
    Print node information to standard output
    """
    headers = {
	    'Content-Type': 'application/soap+xml',
    }
    resp = requests.post(url, headers=headers, data=xml_data)
    resp.raise_for_status()
    return resp

if __name__ == "__main__":
    with open('document.xml', 'r', encoding="utf-8") as file:
        xml_data = file.read()
    try:
        response = make_post_request("http://localhost:8081/pets/")
        print("Status Code:", response.status_code)
        print("Response Text:\n", response.text)
    except requests.exceptions.RequestException as exception:
        print("An error occurred:", exception)
