function ansible {
    statement="$@"
    statement=$(echo $statement | sed 's/\(.*\).*-a \(.*\).*/\1-a "\2"/' |perl -pe "s|(.*)--ssh-extra-args=(-o .*=.*?)( -[^o].*)|\1--ssh-extra-args='\2'\3|")
    ANSIBLE_CONTAINER="${ANSIBLE_CONTAINER:-docker.io/alpine/ansible}"
    ANSIBLE_CONTAINER_LABEL="${ANSIBLE_CONTAINER_LABEL:-latest}"
    docker run --rm -it --network=host -w /ansible -v $(pwd)/ansible:/ansible:Z -v ${HOME}/.ssh/known_hosts:/root/.ssh/known_hosts:Z ${ANSIBLE_CONTAINER}:${ANSIBLE_CONTAINER_LABEL} bash -c "apk add sshpass; ansible $statement"
}

function ansible-playbook {
    statement="$@"
    ANSIBLE_CONTAINER="${ANSIBLE_CONTAINER:-docker.io/alpine/ansible}"
    ANSIBLE_CONTAINER_LABEL="${ANSIBLE_CONTAINER_LABEL:-latest}"
    docker run --rm -it --network=host -w /ansible -v $(pwd)/ansible:/ansible:Z -v ${HOME}/.ssh/known_hosts:/root/.ssh/known_hosts:Z ${ANSIBLE_CONTAINER}:${ANSIBLE_CONTAINER_LABEL} bash -c "apk add py3-netaddr; ansible-playbook $statement"
}

function ansible-galaxy {
    statement="$@"
    ANSIBLE_CONTAINER="${ANSIBLE_CONTAINER:-docker.io/alpine/ansible}"
    ANSIBLE_CONTAINER_LABEL="${ANSIBLE_CONTAINER_LABEL:-latest}"
    docker run --rm -it --network=host -v $(pwd)/ansible:/ansible:Z ${ANSIBLE_CONTAINER}:${ANSIBLE_CONTAINER_LABEL} bash -c "ansible-galaxy $statement"
}

function ansible-inventory {
    statement="$@"
    ANSIBLE_CONTAINER="${ANSIBLE_CONTAINER:-docker.io/alpine/ansible}"
    ANSIBLE_CONTAINER_LABEL="${ANSIBLE_CONTAINER_LABEL:-latest}"
    docker run --rm -it -v $(pwd)/ansible:/ansible:Z ${ANSIBLE_CONTAINER}:${ANSIBLE_CONTAINER_LABEL} bash -c "ansible-inventory $statement"
}

function ansible-vault {
    statement="$@"
    ANSIBLE_CONTAINER="${ANSIBLE_CONTAINER:-docker.io/alpine/ansible}"
    ANSIBLE_CONTAINER_LABEL="${ANSIBLE_CONTAINER_LABEL:-latest}"
    docker run --rm -it -w /ansible -v $(pwd)/ansible:/ansible:Z ${ANSIBLE_CONTAINER}:${ANSIBLE_CONTAINER_LABEL} bash -c "ansible-vault $statement"
}
