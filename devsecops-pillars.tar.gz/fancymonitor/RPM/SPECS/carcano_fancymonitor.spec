%{!?_version: %define _version 0.0.1 }
%{!?pypi_source: %define pypi_source carcano_fancymonitor-%{_version}.tar.gz}
%{!?python3_sitelib: %define python3_sitelib %(python3 -c "import site; print(site.getsitepackages()[-1])")}
%{!?_prefixdir: %define _prefixdir ""}
%{!?_docsdir: %define _docsdir /usr/share/doc/fancymonitor-%{_version}}
%{!?_configdir: %define _configdir /etc/fancymonitor}
%{!?_sharedstatedir: %define _sharedstatedir /var/lib}
%{!?_logsdir: %define _logsdir /var/log/fancymonitor}

%global srcname carcano_fancymonitor

Name:           python3-carcano-fancymonitor-bundle
Version:        %{_version} 
Release:        1%{?dist}
Summary:        Python3 Carcano Fancymonitor
License:        LGPLv3+
Source0:        %{pypi_source}

BuildArch:       noarch
Requires:        python3
%{?python_provide:%python_provide python3-%{srcname}-common}

%description
Python3 Carcano Fancymonitor

%package -n python3-carcano-fancymonitor
Summary:        %{summary}
%{?python_provide:%python_provide python3-%{srcname}-common}
Requires:        python3 python3-pyyaml python3-lxml

%description -n python3-carcano-fancymonitor
Python3 Carcano Fancymonitor Libraries 

%package -n carcano-fancymonitor
Summary:        %{summary}
Requires:       python3-carcano-fancymonitor
%{?python_provide:%python_provide python3-%{srcname}}

%description -n carcano-fancymonitor
Carcano Fancymonitor

%prep
[ -d %{_builddir}/%{srcname}-%{_version} ] && rm -rf %{_builddir}/%{srcname}-%{_version}
%autosetup -n %{srcname}-%{_version}

%build
unset RPM_BUILD_ROOT
sed -i 's/^wheel:\(.*\)*test\(.*\)*/wheel:\1\2/' Makefile
make wheel

%check
cd "%{_builddir}/%{srcname}-%{_version}"
make test

%install
[ "%{buildroot}" != "/" ] && rm -rf %{buildroot}
export ROOT="%{?buildroot}"
export PREFIX="%{?_prefixdir}"
export DOCDIR="%{?_docsdir}"
export CONFDIR="%{?_configdir}"
export SHAREDSTATEDIR="%{?_sharedstatedir}"
export LOGSDIR="%{?_logsdir}"
export SITELIB="%{python3_sitelib}"
%make_install
rm -f %{buildroot}%{python3_sitelib}/Makefile
rm -rf %{buildroot}%{python3_sitelib}/bin
rm -rf %{buildroot}%{python3_sitelib}/doc
rm -rf %{buildroot}%{python3_sitelib}/etc
rm -rf %{buildroot}%{python3_sitelib}/log
rm -rf %{buildroot}%{python3_sitelib}/test

%files -n python3-carcano-fancymonitor
%{python3_sitelib}/carcano/fancymonitor/*.py
%{python3_sitelib}/carcano/fancymonitor/models/*.py
%{python3_sitelib}/carcano/fancymonitor/loaders/*.py
%{python3_sitelib}/carcano/fancymonitor/core/*.py
%{python3_sitelib}/carcano_fancymonitor-%{_version}.dist-info/*
%{python3_sitelib}/carcano/fancymonitor/__pycache__/*.cpython-*.pyc
%{python3_sitelib}/carcano/fancymonitor/models/__pycache__/*.cpython-*.pyc
%{python3_sitelib}/carcano/fancymonitor/loaders/__pycache__/*.cpython-*.pyc
%{python3_sitelib}/carcano/fancymonitor/core/__pycache__/*.cpython-*.pyc

%files -n carcano-fancymonitor
%defattr(644,root,root,755)
%dir %{_sysconfdir}/fancymonitor
%dir %attr(0777, root, root) %{_localstatedir}/log/fancymonitor
%attr(0666, root, root) %{_localstatedir}/log/fancymonitor/*
%config %{_sysconfdir}/fancymonitor/logging.conf
%config %{_sysconfdir}/fancymonitor/config.*
%config %{_sysconfdir}/fancymonitor/schemas/*
%config %{_sysconfdir}/fancymonitor/xslt/*
%attr(755, root, root) %{_bindir}/fancymonitor
%{_docdir}/fancymonitor-%{_version}/*

%changelog
* Wed Feb 26 2025 Marco Antonio Carcano <marco.carcano@carcano.corp>
First release

