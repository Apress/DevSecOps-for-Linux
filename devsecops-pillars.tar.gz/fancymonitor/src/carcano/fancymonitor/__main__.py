import os
import sys
import argparse
import logging.config
from carcano.fancymonitor import *  # noqa: F401,F403
from carcano.fancymonitor.models import Config2JSON  # noqa: F401
import json  # noqa: F401
import yaml

config = None


def main():
    current_version = '0.1.0'
    config_file_path = '../etc/config.xml'
    logconfig_file_path = '../etc/logging.conf'

    parser = argparse.ArgumentParser(description='fancymonitor application')
    parser.add_argument("-c", "--config-file", dest="config_file_path",
                        help="path to the config file - defaults to '{}'".format(config_file_path),
                        default=config_file_path)
    parser.add_argument("-l", "--logconfig", dest="logconfig_file_path",
                        help="path to the configuration file of the Python logging facility - defaults to '{}'".format(
                            logconfig_file_path), default=logconfig_file_path)
    parser.add_argument("-v", "--version", help="print the version and exit", action="store_true")

    args = parser.parse_args()

    if args.version:
        print(current_version)
        exit(0)
    if args.config_file_path:
        config_file_path = args.config_file_path
    if args.logconfig_file_path:
        logconfig_file_path = args.logconfig_file_path

    log_enabled = False
    if os.path.isfile(logconfig_file_path):
        log_enabled = True
    if log_enabled is True:
        logging.config.fileConfig(fname=logconfig_file_path, disable_existing_loggers=False)
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        logging_loglevels = {"NOTSET": 0, "DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40, "CRITICAL": 50}
        logger.setLevel(logging_loglevels[os.getenv("LOGLEVEL", "INFO")])
        logger.info('{}: started'.format(os.path.basename(__file__)))
    try:
        config = load_config(config_file_path)
        # print(repr(config))
        # print(json.dumps(config, cls=Config2JSON, indent=4))
        yaml.dump(config, sys.stdout, default_flow_style=False)
    except Exception as e:
        print(str(e), file=sys.stderr)
        exit(1)


if __name__ == "__main__":
    main()
