__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import json
import yaml
import logging

from lxml import etree
from carcano.fancymonitor.loaders.xml import xmlloader
from carcano.fancymonitor.loaders.json import jsonloader
from carcano.fancymonitor.loaders.yaml import yamlloader

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def load_config(manifest_file_path):
    try:
        log.debug("load_config: processing config file {} as XML".format(manifest_file_path))
        return xmlloader(etree.parse(manifest_file_path), manifest_file_path)
    except FileNotFoundError as e:
        raise Exception("File {} not found".format(manifest_file_path)) from e
    except PermissionError as e:
        raise Exception("Insufficient permission to read {}".format(manifest_file_path)) from e
    except IsADirectoryError as e:
        raise Exception("{} is a directory".format(manifest_file_path)) from e
    except etree.XMLSyntaxError:
        pass
    try:
        log.debug("load_config: processing config file {} as JSON".format(manifest_file_path))
        return jsonloader(json.load(open(manifest_file_path, "r")))
    except json.JSONDecodeError:
        pass
    try:
        return yaml.load(open(manifest_file_path, "rb"),
            Loader=yamlloader(yaml.SafeLoader))  # nosec
    except yaml.YAMLError as e:
        raise Exception("Failed to parse {} as YAML: {}".format(manifest_file_path, e)) from e
