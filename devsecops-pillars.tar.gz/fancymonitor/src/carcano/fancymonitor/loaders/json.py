__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import logging

from carcano.fancymonitor.models.config import Config
from carcano.fancymonitor.models.notify import Notify
from carcano.fancymonitor.models.alert import Alert
from carcano.fancymonitor.models.statement import Statement
from carcano.fancymonitor.models.probe import Probe

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def jsonloader(data):
    try:
        log.debug("jsonloader: loading JSON into objects ...")
        probes = []
        defaults = data.get('defaults')
        for probe_ctx in data['probes']:
            try:
                statement_ctx = probe_ctx['statement']
                statement = Statement(vars=statement_ctx['vars'], interpreter=statement_ctx['interpreter'], command=statement_ctx['command'])
                try:
                    alert_ctx = probe_ctx['alert']
                    notify_ctx = None
                    notify_ctx = alert_ctx.get('notify')
                    notify = None
                    if notify_ctx is not None:
                        try:
                            notify = Notify(command=notify_ctx['command'], arguments=notify_ctx['arguments'], trigger_every=notify_ctx['trigger_every'], message=notify_ctx['message'])
                        except Exception as e:
                            raise KeyError("probe.alert.notify{}".format(str(e))) from e
                    alert = Alert(severity=alert_ctx['severity'], notify=notify)
                except Exception as e:
                    raise KeyError("probe.alert.{}".format(str(e))) from e
                probe = Probe(id=probe_ctx['id'], description=probe_ctx['description'], statement=statement, alert=alert, platforms=probe_ctx['platforms'])
                probes.append(probe)
            except Exception as e:
                raise KeyError("probe.{}".format(str(e))) from e
        config = Config(probes, defaults)
        return config
    except Exception as e:
        raise KeyError("Missing mandatory key or wrong key value: {}".format(str(e))) from e
