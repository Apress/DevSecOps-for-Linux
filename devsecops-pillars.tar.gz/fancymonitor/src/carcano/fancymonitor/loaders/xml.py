__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import logging

from lxml import etree

from carcano.fancymonitor.models.config import Config
from carcano.fancymonitor.models.notify import Notify
from carcano.fancymonitor.models.alert import Alert
from carcano.fancymonitor.models.statement import Statement
from carcano.fancymonitor.models.probe import Probe


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def xmlvalidate(xml_doc, xml_file):
    try:
        root = xml_doc.getroot()
        schema_location = root.get('{http://www.w3.org/2001/XMLSchema-instance}schemaLocation')
        if schema_location:
            schema_parts = schema_location.split()
            if len(schema_parts) < 2:
                raise ValueError("Schema location format is incorrect.")
            schema_file = schema_parts[1].replace('file://', '')
            log.debug("xmlvalidate: validating using XSD file {}".format(schema_file))
            with open(schema_file, 'rb') as schema_file_obj:
                schema_doc = etree.parse(schema_file_obj)
                schema = etree.XMLSchema(schema_doc)
            schema.assertValid(xml_doc)
        else:
            raise ValueError("No schema location found in the XML document.")
    except etree.XMLSyntaxError as e:
        raise Exception("Error parsing XML: {}".format(e)) from e
    except Exception as e:
        raise Exception("{} - validation using schema file {} failed. {}".format(xml_file, schema_file, e)) from e


def xmlloader(tree, xml_file):
    xmlvalidate(tree, xml_file)
    log.debug("xmlloader: loading XML Elements into objects XSD ...")
    root = tree.getroot()
    ns = root.tag.split('}')[0].strip('{')
    probes = []
    for probe_ctx in root.findall(f'{{{ns}}}probe'):
        platforms = [platform.text for platform in probe_ctx.find(f'{{{ns}}}platforms').findall(f'{{{ns}}}platform')]
        stmt_ctx = probe_ctx.find(f'{{{ns}}}statement')
        vars_dict = {}
        for var in stmt_ctx.find(f'{{{ns}}}vars').findall(f'{{{ns}}}var'):
            key, value = var.text.split('=')
            vars_dict[key] = value
        statement = Statement(vars_dict, stmt_ctx.get('interpreter'), stmt_ctx.find(f'{{{ns}}}command').text.strip())
        alrt_ctx = probe_ctx.find(f'{{{ns}}}alert')
        nfy_ctx = alrt_ctx.find(f'{{{ns}}}notify')
        if nfy_ctx is not None:
            notify = Notify(nfy_ctx.get('command'), nfy_ctx.get('arguments'), int(nfy_ctx.get('trigger_every')), nfy_ctx.text.strip())
        else:
            notify = None
        alert = Alert(alrt_ctx.get('severity'), notify)
        probes.append(Probe(int(probe_ctx.get('id')), probe_ctx.find(f'{{{ns}}}description').text, statement, alert, platforms))
    config = Config(probes)
    return config
