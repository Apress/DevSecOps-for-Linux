__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import logging

import yaml

from carcano.fancymonitor.models.config import config_constructor
from carcano.fancymonitor.models.defaults import defaults_constructor
from carcano.fancymonitor.models.notify import notify_constructor
from carcano.fancymonitor.models.alert import alert_constructor
from carcano.fancymonitor.models.statement import statement_constructor
from carcano.fancymonitor.models.probe import probe_constructor


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def yamlloader(loader=None):
    if loader is None:
        loader = yaml.SafeLoader
    loader.add_constructor('tag:carcano.ch,2000:fancymonitor', config_constructor)
    loader.add_constructor('tag:carcano.ch,2000:fancymonitor:defaults', defaults_constructor)
    loader.add_constructor('tag:carcano.ch,2000:fancymonitor:probe:alert:notify', notify_constructor)
    loader.add_constructor('tag:carcano.ch,2000:fancymonitor:probe:alert', alert_constructor)
    loader.add_constructor('tag:carcano.ch,2000:fancymonitor:probe:statement', statement_constructor)
    loader.add_constructor('tag:carcano.ch,2000:fancymonitor:probe', probe_constructor)
    return loader
