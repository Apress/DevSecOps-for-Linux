__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import json
import yaml
import logging
from typing import Optional

from .notify import Notify

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class Alert(yaml.YAMLObject):

    yaml_tag = u'tag:carcano.ch,2000:fancymonitor:probe:alert'

    def __init__(self, severity: str, notify: Optional[Notify] = None):
        self._severity = None
        self._notify = None
        self.severity = severity
        self.notify = notify
        log.debug("Created Alert object")

    @property
    def severity(self):
        return self._severity

    @severity.setter
    def severity(self, severity: str):
        if not isinstance(severity, str):
            raise ValueError("'severity' must be a string")
        if not severity.lower() in ("major", "critical"):
            raise ValueError("'severity' must be be any of 'major', 'critical'")
        self._severity = severity

    @property
    def notify(self):
        return self._notify

    @notify.setter
    def notify(self, notify: Notify):
        if notify is not None:
            if not isinstance(notify, Notify):
                raise ValueError("'notify' must be an instance of Notify")
        self._notify = notify

    def __getstate__(self):
        return {
            'severity': self._severity,
            'notify': self._notify
        }

    def __repr__(self):
        return str(self.__getstate__())

    def __getattribute__(self, item):
        if item == '__dict__':
            self.__getstate__()
        return super().__getattribute__(item)


class Alert2JSON(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Alert) or isinstance(obj, Notify):
            return obj.__dict__
        return super().default(obj)


def alert_constructor(loader: yaml.SafeLoader,
    node: yaml.nodes.MappingNode) -> Alert:
    try:
        return Alert(**loader.construct_mapping(node))
    except TypeError as e:
        raise Exception(str(e)) from e
