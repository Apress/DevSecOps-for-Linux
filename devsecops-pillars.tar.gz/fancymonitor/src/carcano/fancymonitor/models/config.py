__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import json
import yaml
import logging

from .statement import Statement  # noqa: F401
from .alert import Alert  # noqa: F401
from .notify import Notify  # noqa: F401
from .defaults import Defaults  # noqa: F401
from .probe import Probe  # noqa: F401

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class Config(yaml.YAMLObject):

    yaml_tag = u'tag:carcano.ch,2000:fancymonitor'

    _probes = []

    def __init__(self, probes, defaults={}):
        self.probes = probes
        self._defaults = defaults
        log.debug("Created Config object")

    def __del__(self):
        self._probes.clear()

    @property
    def defaults(self):
        return self._defaults

    @defaults.setter
    def defaults(self, defaults):
        if not isinstance(defaults, dict):
            raise ValueError("'defaults' must be a dictionary")
        self._defaults = defaults

    @property
    def probes(self):
        """
        a list of probes the access level is granted
        """
        return self._probes

    @probes.setter
    def probes(self, probes):
        if not isinstance(probes, list):
            raise ValueError("'probes' must be of type 'list'")
        self._probes = probes

    def __getstate__(self):
        jprobes = []
        for probe in self._probes:
            jprobes.append(probe)
        return {
            'defaults': self._defaults,
            'probes': jprobes
        }

    def __repr__(self):
        return str(self.__getstate__())

    def __getattribute__(self, item):
        if item == '__dict__':
            self.__getstate__()
        return super().__getattribute__(item)


class Config2JSON(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Config) or isinstance(obj, Defaults) or isinstance(obj, Probe) or isinstance(obj, Statement) or isinstance(obj, Alert) or isinstance(obj, Notify):
            return obj.__dict__
        return super().default(obj)


def config_constructor(loader: yaml.SafeLoader,
    node: yaml.nodes.MappingNode) -> Config:
    try:
        return Config(**loader.construct_mapping(node))
    except TypeError as e:
        raise Exception(str(e)) from e
