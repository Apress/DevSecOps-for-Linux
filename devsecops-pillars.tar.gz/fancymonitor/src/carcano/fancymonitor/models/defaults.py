__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import json
import yaml
import logging

from .notify import Notify
from .alert import Alert
from .statement import Statement
from .probe import Probe

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class Defaults(yaml.YAMLObject):

    yaml_tag = u'tag:carcano.ch,2000:fancymonitor:defaults'

    def __init__(self, templates):
        self._templates = templates
        log.debug("Created Defaults object")

    @property
    def templates(self):
        return self._templates

    @templates.setter
    def templates(self, templates):
        if not isinstance(templates, dict):
            raise ValueError("'templates' must be a dictionary")
        self._templates = templates

    def __getstate__(self):
        return {
            'templates': self._templates
        }

    def __repr__(self):
        return str(self.__getstate__())

    def __getattribute__(self, item):
        if item == '__dict__':
            self.__getstate__()
        return super().__getattribute__(item)


class Defaults2JSON(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Defaults) or isinstance(obj, Notify) or isinstance(obj, Alert) or isinstance(obj, Statement) or isinstance(obj, Probe):
            return obj.__dict__
        return super().default(obj)


def defaults_constructor(loader: yaml.SafeLoader,
    node: yaml.nodes.MappingNode) -> Defaults:
    try:
        return Defaults(**loader.construct_mapping(node))
    except TypeError as e:
        raise Exception(str(e)) from e
