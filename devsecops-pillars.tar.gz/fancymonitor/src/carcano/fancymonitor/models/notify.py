__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import json
import yaml
import logging

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class Notify(yaml.YAMLObject):

    yaml_tag = u'tag:carcano.ch,2000:fancymonitor:probe:alert:notify'

    def __init__(self, command: str, arguments: str, trigger_every: int, message: str):
        self._command = None
        self._arguments = None
        self._trigger_every = None
        self._message = None
        self.command = command
        self.arguments = arguments
        self.trigger_every = trigger_every
        self.message = message
        log.debug("Created Notify object")

    @property
    def command(self):
        return self._command

    @command.setter
    def command(self, command: str):
        if not isinstance(command, str):
            raise ValueError("'command' must be a string")
        self._command = command

    @property
    def arguments(self):
        return self._arguments

    @arguments.setter
    def arguments(self, arguments: str):
        if not isinstance(arguments, str):
            raise ValueError("'arguments' must be a string")
        self._arguments = arguments

    @property
    def trigger_every(self):
        return self._trigger_every

    @trigger_every.setter
    def trigger_every(self, trigger_every: int):
        if not isinstance(trigger_every, int):
            raise ValueError("'trigger_every' must be an integer")
        if trigger_every < 300 or trigger_every > 3600:
            raise ValueError("'trigger_every' must be an integer between 300 and 3600")
        self._trigger_every = trigger_every

    @property
    def message(self):
        return self._message

    @message.setter
    def message(self, message: str):
        if not isinstance(message, str):
            raise ValueError("'message' must be a string")
        self._message = message

    def __getstate__(self):
        return {
            'command': self._command,
            'arguments': self._arguments,
            'trigger_every': self._trigger_every,
            'message': self._message
        }

    def __repr__(self):
        return str(self.__getstate__())

    def __getattribute__(self, item):
        if item == '__dict__':
            self.__getstate__()
        return super().__getattribute__(item)


class Notify2JSON(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Notify):
            return obj.__dict__
        return super().default(obj)


def notify_constructor(loader: yaml.SafeLoader,
    node: yaml.nodes.MappingNode) -> Notify:
    try:
        return Notify(**loader.construct_mapping(node))
    except TypeError as e:
        raise Exception(str(e)) from e
