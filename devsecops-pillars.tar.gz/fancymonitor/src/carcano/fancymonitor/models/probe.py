__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import json
import yaml
import logging
from .statement import Statement
from .alert import Alert
from .notify import Notify  # noqa: F401

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class Probe(yaml.YAMLObject):

    yaml_tag = u'tag:carcano.ch,2000:fancymonitor:probe'

    _platforms = []

    def __init__(self, id: int, description: str, statement: str, alert: Alert, platforms: list):
        self._id = None
        self._description = None
        self._statement = None
        self._alert = None
        self._platforms = None
        self.id = id
        self.description = description
        self.statement = statement
        self.alert = alert
        self.platforms = platforms
        log.debug("Created Probe object")

    def __del__(self):
        self._platforms.clear()

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id: int):
        if not isinstance(id, int):
            raise ValueError("'id' must be a n integer")
        self._id = id

    @property
    def description(self):
        return self._description

    @description.setter
    def description(self, description: str):
        if not isinstance(description, str):
            raise ValueError("'description' must be a string")
        self._description = description

    @property
    def statement(self):
        return self._statement

    @statement.setter
    def statement(self, statement: str):
        if not isinstance(statement, Statement):
            raise ValueError("'statement' must be an instance of Statement")
        self._statement = statement

    @property
    def alert(self):
        return self._alert

    @alert.setter
    def alert(self, alert: Alert):
        if not isinstance(alert, Alert):
            raise ValueError("'alert' must be an instance of Alert")
        self._alert = alert

    @property
    def platforms(self):
        """
        a list of platforms the access level is granted
        """
        return self._platforms

    @platforms.setter
    def platforms(self, platforms: list):
        if not isinstance(platforms, list):
            raise ValueError("'platforms' must be of type 'list'")
        self._platforms = platforms

    def __getstate__(self):
        return {
            'id': self._id,
            'description': self._description,
            'statement': self._statement,
            'alert': self._alert,
            'platforms': self._platforms
        }

    def __repr__(self):
        return str(self.__getstate__())

    def __getattribute__(self, item):
        if item == '__dict__':
            self.__getstate__()
        return super().__getattribute__(item)


class Probe2JSON(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Probe) or isinstance(obj, Statement) or isinstance(obj, Alert) or isinstance(obj, Notify):
            return obj.__dict__
        return super().default(obj)


def probe_constructor(loader: yaml.SafeLoader,
    node: yaml.nodes.MappingNode) -> Probe:
    try:
        return Probe(**loader.construct_mapping(node))
    except TypeError as e:
        raise Exception(str(e)) from e
