__author__ = "Marco Antonio Carcano"
__version__ = '0.1.0'

import json
import yaml
import logging

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class Statement(yaml.YAMLObject):

    yaml_tag = u'tag:carcano.ch,2000:fancymonitor:probe:statement'

    def __init__(self, vars: dict, interpreter: str, command: str):
        self._vars = None
        self._interpreter = None
        self_command = None  # noqa: F841
        self.vars = vars
        self.interpreter = interpreter
        self.command = command
        log.debug("Created Statement object")

    @property
    def vars(self):
        return self._vars

    @vars.setter
    def vars(self, vars: dict):
        if not isinstance(vars, dict):
            raise ValueError("'vars' must be a dictionary")
        self._vars = vars

    @property
    def interpreter(self):
        return self._interpreter

    @interpreter.setter
    def interpreter(self, interpreter: str):
        if not isinstance(interpreter, str):
            raise ValueError("'interpreter' must be a string")
        self._interpreter = interpreter

    @property
    def command(self):
        return self._command

    @command.setter
    def command(self, command: str):
        if not isinstance(command, str):
            raise ValueError("'command' must be a string")
        self._command = command

    def __getstate__(self):
        return {
            'vars': self._vars,
            'interpreter': self._interpreter,
            'command': self._command
        }

    def __repr__(self):
        return str(self.__getstate__())

    def __getattribute__(self, item):
        if item == '__dict__':
            self.__getstate__()
        return super().__getattribute__(item)


class Statement2JSON(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Statement):
            return obj.__dict__
        return super().default(obj)


def statement_constructor(loader: yaml.SafeLoader,
    node: yaml.nodes.MappingNode) -> Statement:
    try:
        return Statement(**loader.construct_mapping(node))
    except TypeError as e:
        raise Exception(str(e)) from e
