<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:c="https://www.carcano.corp">
<xsl:output method="html" version="4.0" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html>
    <head>
        <style>
            #probes table 
            {
                border-spacing: 0px;
                border-collapse: separate;
            }
            #probes td 
            {
                text-align: left; 
                vertical-align: middle;
                padding: 5px;
            }
        </style>
    </head>
    <body>
    <h2>Alerts List</h2>
        <table id="probes" border="1">
            <tr bgcolor="#ff6600">
                <th>Alerts</th>
            </tr>
            <tr>
                <td>
                    <xsl:apply-templates select="c:probes"/>
                </td>
            </tr>
        </table>
    </body>
</html>
</xsl:template>
<xsl:template match="c:alert">
    <tr>
        <th style="border-bottom-style: solid;border-bottom: thin short;">Notifications</th>
        <td colspan="7" style="border-bottom-style: solid;border-bottom: thin short;">
            <table border="0">
                <xsl:for-each select="c:notify">
                <tr>
                    <th>Command:</th>
                    <td><xsl:value-of select="@command"/></td>
                    <th>Arguments:</th>
                    <td><xsl:value-of select="@arguments"/></td>
                    <th>Retrigger every seconds:</th>
                    <td><xsl:value-of select="@trigger_every"/></td>
                </tr>
                <tr>
                    <th>Message:</th>
                    <td colspan="5"><xsl:value-of select="."/></td>
                </tr>
                </xsl:for-each>
            </table>
        </td>
    </tr> 
</xsl:template>
<xsl:template match="c:statement">
    <tr>
        <th>Vars:</th>
	<td colspan="4">
            <xsl:for-each select="c:vars/c:var">
                <xsl:value-of select="."/>
                <xsl:text>;&#160;</xsl:text>
            </xsl:for-each>
	</td>
        <th>Interpreter:</th>
	<td><xsl:value-of select="c:command/@interpreter"/></td>
    </tr> 
    <tr>
        <th>Command:</th>
        <td colspan="7"><xsl:value-of select="c:command"/></td>
    </tr> 
</xsl:template>
<xsl:template match="c:probes">
    <table border="0">
        <tr>
            <th style="border-bottom-style: solid;border-bottom: thin short;">Id</th>
            <th style="border-bottom-style: solid;border-bottom: thin short;">Severity</th>
            <th colspan="7" style="border-bottom-style: solid;border-bottom: thin short;">Description</th>
        </tr> 
        <xsl:for-each select="c:probe">
        <tr>
            <td rowspan="5" style="border-bottom-style: solid;border-bottom: thin short;"><xsl:value-of select="@id"/></td>
	    <td rowspan="5" style="border-bottom-style: solid;border-bottom: thin short;"><xsl:value-of select="c:alert/@severity"/></td>
            <td colspan="7"><xsl:value-of select="c:description"/></td>
        </tr>
	<tr>
            <th>Platforms:</th>
	    <td colspan="6">
                <xsl:for-each select="c:platforms/c:platform">
                    <xsl:value-of select="."/>
                    <xsl:text>;&#160;</xsl:text>
                </xsl:for-each>
	    </td>
        </tr> 
        <xsl:apply-templates select="c:statement"/>
        <xsl:apply-templates select="c:alert"/>
        </xsl:for-each>
    </table>
</xsl:template>
</xsl:stylesheet>
